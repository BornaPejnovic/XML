<!DOCTYPE html>
<html>
<head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>The Archive</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
  <style>
    h1 {
      text-align: center;
    }
    .article {
      background-color: #f5f5f5;
      border-radius: 5px;
      padding: 20px;
      margin-bottom: 20px;
    }
    .article h2 {
      font-size: 20px;
      margin-bottom: 10px;
    }
    .article p {
      font-size: 16px;
      color: #666;
      margin-bottom: 0;
    }
  </style>
</head>
<body>
<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
         <a class="nav-link active" href="index.php">
          <?php
          session_start();
          $username = $_SESSION['Name'];
          echo $username;
          ?>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href='Vjesti.php'>News</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href='ListaKnjiga.php'>Book List</a>
        </li>
      </ul>
    </div>
  </div>
</nav>
  <h1>News Site</h1>
  <?php
    $xml = simplexml_load_file('news.xml');
    foreach ($xml->article as $article) {
      $title = (string)$article->title;
      $description = (string)$article->description;
  ?>
  <div class="article">
    <h2><?php echo $title; ?></h2>
    <p><?php echo $description; ?></p>
  </div>
  <?php
    }
  ?>
</body>
</html>
