<!doctype html>
<html lang="en">
  <head>
    <style>
      h2 {
  font-size: 24px;
  font-weight: bold;
  color: #333;
  margin-bottom: 10px;
  text-align: center;
}
    </style>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>The Archive</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
  </head>
  <body>
  <nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
         <a class="nav-link active" href="index.php">
          <?php
          session_start();
          $Username = $_SESSION['Name'];
          echo $Username;
          ?>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href='Vjesti.php'>News</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href='ListaKnjiga.php'>Book List</a>
        </li>
      </ul>
    </div>
  </div>
</nav>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>

<?php
$xml = simplexml_load_file('users.xml');

$name = $_SESSION['user'];

foreach ($xml->user as $user) {
  $xmlusername = (string)$user->username;
  $xmlname = (string)$user->ime;
  $xmllastName = (string)$user->prezime;

  if ($xmlusername == $name) {
    echo "<h2>Username: $name</h2><br>";
    echo "<h2>Name: $xmlname</h2><br>";
    echo "<h2>Last Name: $xmllastName</h2><br>";
    echo "<br>";
    exit();
  }
}
?>
  </body>
</html>