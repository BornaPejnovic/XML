<!DOCTYPE html>
<html>
<meta charset="utf-8">
<style>
    label {
  font-family: Arial, sans-serif;
  font-size: 16px;
  line-height: 1.5;
  color: #333;
  margin: 0;
  padding: 20px;
  width: 150px;
}

</style>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>The Archive</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
  </head>
<body>
<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
         <a class="nav-link active" href="index.php">
          <?php
          session_start();
          $username = $_SESSION['Name'];
          echo $username;
          ?>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href='Vjesti.php'>News</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href='ListaKnjiga.php'>Book List</a>
        </li>
      </ul>
    </div>
  </div>
</nav>
  <h2>Book Registration</h2>
  <form action="DodajKnjige.php" method="post">
    <label for="author">Author:</label>
    <input type="text" name="author" id="author" required><br>

    <label for="book_name">Book Name:</label>
    <input type="text" name="book_name" id="book_name" required><br>

    <label for="year_of_release">Year of Release:</label>
    <input type="text" name="year_of_release" id="year_of_release" required><br>

    <label for="quote">Quote:</label>
    <textarea name="quote" id="quote" required></textarea><br>

    <input type="submit" value="Register">

    <a href="ListaKnjiga.php"><input type="button" value="Go Back"></a>
  </form>
</body>
</html>


<?php
if(isset($_POST['author'])&&$_POST['book_name']&&$_POST['year_of_release']&&$_POST['quote']){
$author = $_POST['author'];
$bookName = $_POST['book_name'];
$yearOfRelease = $_POST['year_of_release'];
$quote = $_POST['quote'];

$bookData = [
    'author' => $author,
    'year' => $yearOfRelease,
    'book' => $bookName,
    'quote' => $quote
  ];

$quotesFile = 'quotes.json';
if (file_exists($quotesFile)) {
   $quotes = json_decode(file_get_contents($quotesFile), true);
} else {
   $quotes = [];
}
    $quotes[] = $bookData;
    file_put_contents($quotesFile, json_encode($quotes));
    echo 'Book registration successful!';
}
?>
