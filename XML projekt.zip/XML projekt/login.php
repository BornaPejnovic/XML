<!DOCTYPE html>
<html>
<head>
  <title>The Archive</title>
  <style>
  </style>
</head>
<body>
  <h1>Sign In</h1>
  <form method="post" action="login.php">
    <label for="username">Username:</label>
    <input type="text" id="username" name="username" required><br><br>
    <label for="password">Password:</label>
    <input type="password" id="password" name="password" required><br><br>
    <input type="submit" value="Sign In">
    <a href="register.php"><input type="button" value="Register"></a>
  </form>
</body>
</html>

<?php
session_start();
if(isset($_POST['username'])&&$_POST['password']){
	$username = $_POST['username'];
  $password = $_POST['password'];
	$xml = simplexml_load_file('users.xml');

foreach ($xml->user as $user) {
  $xmlUsername = (string)$user->username;
  $xmlPassword = (string)$user->password;
  $xmlName = (string)$user->ime;

  if ($xmlUsername === $username && $xmlPassword === $password) {
    header("Location: index.php");
	$_SESSION['Name'] = $xmlName;
  $_SESSION["user"] = $xmlUsername;
    exit();
  }
}

echo 'Invalid username or password.';
}
?>
